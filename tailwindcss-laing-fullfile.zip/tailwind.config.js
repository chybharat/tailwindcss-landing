/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./*.html",
    "./dist/**/*.html",
    "./js/**/*.js",
    "./src/**/*.js"
  ],

  safelist: [
    'owl-dots',
    'owl-dot',
    'active'
  ],

  theme: {
    extend: {
      fontFamily: {
        site: ['"Tenor Sans"', 'sans-serif'],
      },
    },
  },

  plugins: [],
}

